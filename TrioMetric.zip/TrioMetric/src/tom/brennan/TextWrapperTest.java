package tom.brennan;

import static org.junit.Assert.*;

import org.junit.Test;

public class TextWrapperTest {

	@Test
	public void test20Width() {
		 TextWrapper tw = new TextWrapper();

		 tw.main(new String[] {"input.txt", "20"});
		 
	}
	
	@Test
	public void test10Width() {
		 TextWrapper tw = new TextWrapper();

		tw.main(new String[] {"input.txt", "10"});
		 
	}
	
	@Test
	public void testInputWrongOrder() {
		 TextWrapper tw = new TextWrapper();

		tw.main(new String[] {"20", "input.txt"});
		 
	}
	
	@Test
	public void test1Width() {
		 TextWrapper tw = new TextWrapper();

		tw.main(new String[] {"input.txt", "1"});
		 
	}

}
