package com.mendeley.coding;

import java.util.List;

public class CheckoutApplication {

    public static void main(String[] args) {

        if (args.length < 1) {
            throw new RuntimeException("No path to the input list was provided.");
        }

        String filePath = args[0];

        List<Item> itemList = new ListReader().read(filePath);

        Checkout basicCheckout = new BasicCheckout();

        String output = basicCheckout.checkout(itemList);
    }
}
