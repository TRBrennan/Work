package com.mendeley.coding;

import java.math.BigDecimal;
import java.util.List;

public class BasicCheckout implements Checkout {
    @Override
    public String checkout(List<Item> items) {
        StringBuilder stringBuilder = new StringBuilder();

        items.forEach(item -> stringBuilder
                .append(item.getName())
                .append(" : £")
                .append(item.getPrice())
                .append("\n"));

        BigDecimal sum = items.stream().map(Item::getPrice).reduce(BigDecimal.ZERO, BigDecimal::add);
        stringBuilder.append("total price : £").append(sum);

        String output = stringBuilder.toString();

        System.out.print(output);

        return output;
    }
}
